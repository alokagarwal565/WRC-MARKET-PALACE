const shadows = {
  outline: "0 0 0 3px #F4EBFF",
};

export default shadows;
