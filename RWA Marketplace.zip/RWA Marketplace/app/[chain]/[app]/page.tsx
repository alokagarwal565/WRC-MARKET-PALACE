"use client";
import { DiscoverPage } from "@/modules/discover";
import React, { FC } from "react"

interface Props {
}

const Page: FC<Props> = (props) => {
    const { } = props;
    return (
        <DiscoverPage />
    )
}

export default Page